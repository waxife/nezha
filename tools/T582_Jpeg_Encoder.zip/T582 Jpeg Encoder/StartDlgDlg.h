// StartDlgDlg.h : header file
//

#if !defined(AFX_STARTDLGDLG_H__B22C64F9_F7E4_4931_84D9_AFD9CFC6F35A__INCLUDED_)
#define AFX_STARTDLGDLG_H__B22C64F9_F7E4_4931_84D9_AFD9CFC6F35A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JpegEncoder.h"
/////////////////////////////////////////////////////////////////////////////
// CStartDlgDlg dialog
struct ThreadInfo
{
	int ThrdNum;
	unsigned short Height;
	unsigned short Width;
	unsigned char * pImageData;
//	JpegEncoder *	Jpeg;
	
} ;
class CStartDlgDlg : public CDialog
{
// Construction
public:
	CStartDlgDlg(CWnd* pParent = NULL);	// standard constructor
	unsigned char *pBitbuffer;
	unsigned short nWidth,nHeight;
// Dialog Data
	//{{AFX_DATA(CStartDlgDlg)
	enum { IDD = IDD_STARTDLG_DIALOG };
	CString	m_FileName;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStartDlgDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CFile pFileOpen;
	unsigned char *pbuf;
	
	//CFile pFileOpen;
	HICON m_hIcon;
//	JpegEncoder Jpeg;
	
	//StepJPEG stepjpeg;
//	Huffman huffmancode;
	// Generated message map functions
	//{{AFX_MSG(CStartDlgDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnOpenFileBUTTON();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnChangeFileNameEDIT();
	afx_msg void OnBUTTONThread();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
		friend DWORD WINAPI ThreadFunc(LPVOID n);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STARTDLGDLG_H__B22C64F9_F7E4_4931_84D9_AFD9CFC6F35A__INCLUDED_)
