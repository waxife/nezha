// JpegEncoder.h: interface for the JpegEncoder class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_JPEGENCODER_H__E7254248_22B2_4F99_8E5C_207BB26339A5__INCLUDED_)
#define AFX_JPEGENCODER_H__E7254248_22B2_4F99_8E5C_207BB26339A5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "jtypes.h"
#include "jtables.h"
//#define Integer
//static BYTE bytenew=0; // The byte that will be written in the JPG file
static WORD bytenew=0; // The WORD that will be written in the JPG file

static SBYTE bytepos=7; //bit position in the byte we write (bytenew)
				//should be<=7 and >=0
static WORD mask[16]={1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768};

class JpegEncoder  
{
private:
	BYTE *m_pFile_Temp;
	BYTE *m_pFile_Temp_Org;
	unsigned long m_Byte_Count;
	BYTE *m_pBitTemp;
	unsigned short m_ByteCount;
	// The Huffman tables we'll use:
	bitstring m_YDC_HT[12];
	bitstring m_CbDC_HT[12];
	bitstring m_YAC_HT[256];
	bitstring m_CbAC_HT[256];
	unsigned long m_TempSize;
	BYTE *m_pCategory_alloc;
	BYTE *m_pCategory; //Here we'll keep the category of the numbers in range: -32767..32767
	bitstring *m_pBitcode_alloc;
	bitstring *m_pBitcode; // their bitcoded representation
#ifdef Integer
	long m_fdtbl_Y[64];
	long m_fdtbl_Cb[64];
	void Process_DU(SBYTE *ComponentDU,long *fdtbl,SWORD *DC,bitstring *HTDC,bitstring *HTAC);
	void Fdct_and_Quantization(SBYTE *data,long *fdtbl,SWORD *outdata);
#else
	float m_fdtbl_Y[64];
	float m_fdtbl_Cb[64]; //the same with the fdtbl_Cr[64]
	void Process_DU(SBYTE *ComponentDU,float *fdtbl,SWORD *DC,bitstring *HTDC,bitstring *HTAC);
	void Fdct_and_Quantization(SBYTE *data,float *fdtbl,SWORD *outdata);
#endif
	//Precalculated tables for a faster YCbCr->RGB transformation
	// We use a SDWORD table because we'll scale values by 2^16 and work with integers
	SDWORD m_YRtab[256],m_YGtab[256],m_YBtab[256];
	SDWORD m_CbRtab[256],m_CbGtab[256],m_CbBtab[256];
	SDWORD m_CrRtab[256],m_CrGtab[256],m_CrBtab[256];
	
	colorRGB *m_pRGB_buffer; //image to be encoded
	WORD m_Ximage,m_Yimage;// image dimensions divisible by 8
	SBYTE m_YDU[64],m_YDU1[64],m_YDU2[64]; // This is the Data Unit of Y after YCbCr->RGB transformation
	SBYTE m_CbDU[64],m_CbDU1[64];
	SBYTE m_CrDU[64],m_CrDU1[64];
	SWORD m_DU_DCT[64]; // Current DU (after DCT and quantization) which we'll zigzag
	SWORD m_DU[64]; //zigzag reordered DU which will be Huffman coded

	
	void Prepare_RGB(unsigned char *bitmap_name, WORD *Ximage_original, WORD *Yimage_original);

	void Writebits(bitstring bs);

	void Write_comment(char *comment);
	void Set_quant_table(BYTE *basic_table,BYTE scale_factor,BYTE *newtable);
	void Set_numbers_category_and_bitcode();
	void Set_DQTinfo(BYTE scalefactor);
	void Set_DHTinfo();
	void Prepare_quant_tables();
	void Precalculate_YCbCr_tables();
	void Load_Data_Units_From_RGB_Buffer(WORD xpos,WORD ypos);
    void Load_Data_Units_From_RGB_Buffer2x1(WORD xpos,WORD ypos);
	void Compute_Huffman_table(BYTE *nrcodes,BYTE *std_table,bitstring *HT);
	void Init_Huffman_Tables();
	
	

	void writeword(WORD Num)
	{
	    BYTE Token[2]={(Num>>8),(BYTE)Num};
	    writebyte(Token[0]);
	    writebyte(Token[1]);
	}
	void Encoder();
    void Encoder2x1();	
void Init_all(BYTE Quality);	
public:
	JpegEncoder();
	~JpegEncoder();
	//*****************For Compress image directly ****************************************
	bool Compressor(BYTE *Bitmap, WORD nWidth_original, WORD nHeight_original, BYTE Quality);
    BYTE * GetJpegFileStream(DWORD *Jpg_FileSize);
	//**************************************************************************************


};

#endif // !defined(AFX_JPEGENCODER_H__E7254248_22B2_4F99_8E5C_207BB26339A5__INCLUDED_)
