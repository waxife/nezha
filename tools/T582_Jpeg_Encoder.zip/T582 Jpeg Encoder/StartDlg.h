// StartDlg.h : main header file for the STARTDLG application
//

#if !defined(AFX_STARTDLG_H__98D45723_F070_4BD8_8566_D29761BF8DA9__INCLUDED_)
#define AFX_STARTDLG_H__98D45723_F070_4BD8_8566_D29761BF8DA9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CStartDlgApp:
// See StartDlg.cpp for the implementation of this class
//

class CStartDlgApp : public CWinApp
{
public:
	CStartDlgApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStartDlgApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CStartDlgApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STARTDLG_H__98D45723_F070_4BD8_8566_D29761BF8DA9__INCLUDED_)
