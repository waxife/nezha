// JpegEncoder.cpp: implementation of the JpegEncoder class.
//
//////////////////////////////////////////////////////////////////////
/*/////////////////////////////////////////////////////////////////////
Company: PIE
Programer: Kevin Hsu.
Date: 203/09/03
Thist version we try to save data in memory at firse.
Then save to file every 10kByte.
*////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "JpegEncoder.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
//#define Integer

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

JpegEncoder::JpegEncoder()
{
    m_pFile_Temp_Org = NULL;
    m_Byte_Count=0;
}

JpegEncoder::~JpegEncoder()
{
     if(m_pFile_Temp_Org != NULL)
        delete [] m_pFile_Temp_Org;
}

void JpegEncoder::Init_all(BYTE Quality)
{
     APP0info.q = Quality;
     Set_DQTinfo(Quality);
	 Set_DHTinfo();
	 Init_Huffman_Tables();
	 Set_numbers_category_and_bitcode();
	 Precalculate_YCbCr_tables();
	 Prepare_quant_tables();
}

void JpegEncoder::Encoder()
{
	SWORD DCY=0,DCCb=0,DCCr=0; //DC coefficients used for differential encoding
	WORD xpos,ypos;
	for (ypos=0;ypos<m_Yimage;ypos+=8)
	{
		for (xpos=0;xpos<m_Ximage;xpos+=8)
		{
			Load_Data_Units_From_RGB_Buffer(xpos,ypos);
			Process_DU(m_YDU,m_fdtbl_Y,&DCY,m_YDC_HT,m_YAC_HT);
			Process_DU(m_CbDU,m_fdtbl_Cb,&DCCb,m_CbDC_HT,m_CbAC_HT);
			Process_DU(m_CrDU,m_fdtbl_Cb,&DCCr,m_CbDC_HT,m_CbAC_HT);
		}
	}
}
void JpegEncoder::Encoder2x1()
{
    SWORD DCY1=0,DCY2=0,DCY3=0,DCY4=0,DCCb1=0,DCCr1=0;
	WORD xpos,ypos;

    for (ypos=0;ypos<m_Yimage;ypos+=8)
	{
		for (xpos=0;xpos<m_Ximage;xpos+=16)
		{
			Load_Data_Units_From_RGB_Buffer2x1(xpos,ypos);
			Process_DU(m_YDU1,m_fdtbl_Y,&DCY1,m_YDC_HT,m_YAC_HT);
            Process_DU(m_YDU2,m_fdtbl_Y,&DCY1,m_YDC_HT,m_YAC_HT);
			Process_DU(m_CbDU1,m_fdtbl_Cb,&DCCb1,m_CbDC_HT,m_CbAC_HT);
			Process_DU(m_CrDU1,m_fdtbl_Cb,&DCCr1,m_CbDC_HT,m_CbAC_HT);
		}
	}
}
void JpegEncoder::Init_Huffman_Tables()
{
	Compute_Huffman_table(std_dc_luminance_nrcodes,std_dc_luminance_values,m_YDC_HT);
	Compute_Huffman_table(std_dc_chrominance_nrcodes,std_dc_chrominance_values,m_CbDC_HT);
	Compute_Huffman_table(std_ac_luminance_nrcodes,std_ac_luminance_values,m_YAC_HT);
	Compute_Huffman_table(std_ac_chrominance_nrcodes,std_ac_chrominance_values,m_CbAC_HT);
}

void JpegEncoder::Compute_Huffman_table(BYTE *nrcodes, BYTE *std_table, bitstring *HT)
{
	BYTE k,j;
	BYTE pos_in_table;
	WORD codevalue;
	codevalue=0; pos_in_table=0;
	for (k=1;k<=16;k++)
	{
		for (j=1;j<=nrcodes[k];j++) 
		{
			HT[std_table[pos_in_table]].value=codevalue;
			HT[std_table[pos_in_table]].length=k;
			pos_in_table++;
			codevalue++;
		}
		codevalue*=2;
	}
}
void JpegEncoder::Prepare_RGB(unsigned char *Bitmap, WORD *Ximage_original, WORD *Yimage_original)
{
	//I let m_Ximage and m_Yimage point to Ximage_original and Yimage_original directly.
	if((((*Ximage_original)%8)==0)&&(((*Yimage_original)%8)==0))
	{
		m_pRGB_buffer=(colorRGB *)Bitmap;
		m_Ximage=*Ximage_original;
		m_Yimage=*Yimage_original;
	}
	
	else
	{
		WORD Xdiv8,Ydiv8;
		WORD nrline;
		WORD dimline;
		WORD column;
		colorRGB *tmpline;
		colorRGB lastcolor;
		m_Ximage=*Ximage_original;
		m_Yimage=*Yimage_original;

		*Ximage_original=m_Ximage;
		*Yimage_original=m_Yimage; //Keep the old dimensions of the image
		
		if (m_Ximage%8!=0) Xdiv8=(m_Ximage/8)*8+8;
		else Xdiv8=m_Ximage;
		if (m_Yimage%8!=0) Ydiv8=(m_Yimage/8)*8+8;
		else Ydiv8=m_Yimage;
		m_pRGB_buffer=new colorRGB[Xdiv8*Ydiv8];
		tmpline=new colorRGB[Xdiv8];
		for (nrline=0;nrline<m_Yimage;nrline++)
		{
			memcpy(m_pRGB_buffer+nrline*Xdiv8,Bitmap+nrline*m_Ximage*3,m_Ximage*3);
			memcpy(&lastcolor,m_pRGB_buffer+nrline*Xdiv8+m_Ximage-1,3);
			for (column=m_Ximage;column<Xdiv8;column++)
			{
			   memcpy(m_pRGB_buffer+nrline*Xdiv8+column,&lastcolor,3);
			}
		}
		dimline=Xdiv8*3;
		memcpy(tmpline,m_pRGB_buffer+(m_Yimage-1)*m_Ximage,dimline);
		for (nrline=m_Yimage;nrline<Ydiv8;nrline++)
		{
			memcpy(m_pRGB_buffer+nrline*m_Ximage,tmpline,dimline);
		}
		m_Ximage=Xdiv8;
		m_Yimage=Ydiv8;
		delete [] tmpline;
	}
}

 
void JpegEncoder::Fdct_and_Quantization(SBYTE *data, float *fdtbl, SWORD *outdata)
{
	float tmp0, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7;
	float tmp10, tmp11, tmp12, tmp13;
	float z1, z2, z3, z4, z5, z11, z13;
	float *dataptr;
	float datafloat[64];
	float temp;
	SBYTE ctr;
	BYTE i;
	for (i=0;i<64;i++) datafloat[i]=data[i];

	/* Pass 1: process rows. */
	dataptr=datafloat;
	for (ctr = 7; ctr >= 0; ctr--) 
	{
		tmp0 = dataptr[0] + dataptr[7];
		tmp7 = dataptr[0] - dataptr[7];
		tmp1 = dataptr[1] + dataptr[6];
		tmp6 = dataptr[1] - dataptr[6];
		tmp2 = dataptr[2] + dataptr[5];
		tmp5 = dataptr[2] - dataptr[5];
		tmp3 = dataptr[3] + dataptr[4];
		tmp4 = dataptr[3] - dataptr[4];

		/* Even part */

		tmp10 = tmp0 + tmp3;	/* phase 2 */
		tmp13 = tmp0 - tmp3;
		tmp11 = tmp1 + tmp2;
		tmp12 = tmp1 - tmp2;

		dataptr[0] = tmp10 + tmp11; /* phase 3 */
		dataptr[4] = tmp10 - tmp11;

		z1 = (tmp12 + tmp13) * ((float) 0.707106781); /* c4 */
		dataptr[2] = tmp13 + z1;	/* phase 5 */
		dataptr[6] = tmp13 - z1;

		/* Odd part */

		tmp10 = tmp4 + tmp5;	/* phase 2 */
		tmp11 = tmp5 + tmp6;
		tmp12 = tmp6 + tmp7;

		/* The rotator is modified from fig 4-8 to avoid extra negations. */
		z5 = (tmp10 - tmp12) * ((float) 0.382683433); /* c6 */
		z2 = ((float) 0.541196100) * tmp10 + z5; /* c2-c6 */
		z4 = ((float) 1.306562965) * tmp12 + z5; /* c2+c6 */
		z3 = tmp11 * ((float) 0.707106781); /* c4 */

		z11 = tmp7 + z3;		/* phase 5 */
		z13 = tmp7 - z3;

		dataptr[5] = z13 + z2;	/* phase 6 */
		dataptr[3] = z13 - z2;
		dataptr[1] = z11 + z4;
		dataptr[7] = z11 - z4;

		dataptr += 8;		/* advance pointer to next row */
	}

	/* Pass 2: process columns. */

	dataptr = datafloat;
	for (ctr = 7; ctr >= 0; ctr--) 
	{
		tmp0 = dataptr[0] + dataptr[56];
		tmp7 = dataptr[0] - dataptr[56];
		tmp1 = dataptr[8] + dataptr[48];
		tmp6 = dataptr[8] - dataptr[48];
		tmp2 = dataptr[16] + dataptr[40];
		tmp5 = dataptr[16] - dataptr[40];
		tmp3 = dataptr[24] + dataptr[32];
		tmp4 = dataptr[24] - dataptr[32];

		/* Even part */

		tmp10 = tmp0 + tmp3;	/* phase 2 */
		tmp13 = tmp0 - tmp3;
		tmp11 = tmp1 + tmp2;
		tmp12 = tmp1 - tmp2;

		dataptr[0] = tmp10 + tmp11; /* phase 3 */
		dataptr[32] = tmp10 - tmp11;

		z1 = (tmp12 + tmp13) * ((float) 0.707106781); /* c4 */
		dataptr[16] = tmp13 + z1; /* phase 5 */
		dataptr[48] = tmp13 - z1;

		/* Odd part */

		tmp10 = tmp4 + tmp5;	/* phase 2 */
		tmp11 = tmp5 + tmp6;
		tmp12 = tmp6 + tmp7;

		/* The rotator is modified from fig 4-8 to avoid extra negations. */
		z5 = (tmp10 - tmp12) * ((float) 0.382683433); /* c6 */
		z2 = ((float) 0.541196100) * tmp10 + z5; /* c2-c6 */
		z4 = ((float) 1.306562965) * tmp12 + z5; /* c2+c6 */
		z3 = tmp11 * ((float) 0.707106781); /* c4 */

		z11 = tmp7 + z3;		/* phase 5 */
		z13 = tmp7 - z3;

		dataptr[40] = z13 + z2; /* phase 6 */
		dataptr[24] = z13 - z2;
		dataptr[8] = z11 + z4;
		dataptr[56] = z11 - z4;

		dataptr++;			/* advance pointer to next column */
	}

	// Quantize/descale the coefficients, and store into output array
	for (i = 0; i < 64; i++)
	{
		/* Apply the quantization and scaling factor */
		temp = datafloat[i] * fdtbl[i];
	
		outdata[i] = (SWORD) ((SWORD)(temp + 16384.5) - 16384);
	}

}

void JpegEncoder::Load_Data_Units_From_RGB_Buffer(WORD xpos, WORD ypos)
{
	BYTE x,y;
	BYTE pos=0;
	DWORD location;
	location=ypos*m_Ximage+xpos;
	for (y=0;y<8;y++)
	{
		for (x=0;x<8;x++)
		{
			
			m_YDU[pos] =Y (m_pRGB_buffer[location].R, m_pRGB_buffer[location].G, m_pRGB_buffer[location].B);
			m_CbDU[pos]=Cb(m_pRGB_buffer[location].R, m_pRGB_buffer[location].G, m_pRGB_buffer[location].B);
			m_CrDU[pos]=Cr(m_pRGB_buffer[location].R, m_pRGB_buffer[location].G, m_pRGB_buffer[location].B);
			location++;pos++;
		}
		location+=m_Ximage-8;
	}
}
void JpegEncoder::Load_Data_Units_From_RGB_Buffer2x1(WORD xpos, WORD ypos)
{
	BYTE x,y;
	BYTE pos=0;
	DWORD location, location2;

	location=ypos*m_Ximage+xpos;
    location2 = ypos*m_Ximage+xpos;
	for (y=0;y<8;y++)
	{
		for (x=0;x<8;x++)
		{
			
			m_YDU1[pos] =Y (m_pRGB_buffer[location].R, m_pRGB_buffer[location].G, m_pRGB_buffer[location].B);
			m_CbDU1[pos]=Cb((m_pRGB_buffer[location2].R+m_pRGB_buffer[location2+1].R)/2, (m_pRGB_buffer[location2].G+m_pRGB_buffer[location2+1].G)/2, (m_pRGB_buffer[location2].B+m_pRGB_buffer[location2+1].B)/2);
			m_CrDU1[pos]=Cr((m_pRGB_buffer[location2].R+m_pRGB_buffer[location2+1].R)/2, (m_pRGB_buffer[location2].G+m_pRGB_buffer[location2+1].G)/2, (m_pRGB_buffer[location2].B+m_pRGB_buffer[location2+1].B)/2);
			location++;pos++;
            location2 += 2;
		}
		location+=m_Ximage-8;
        location2+=m_Ximage-16;
	}
    location=ypos*m_Ximage+xpos+8;
    pos=0;
	for (y=0;y<8;y++)
	{
		for (x=0;x<8;x++)
		{
			
			m_YDU2[pos] =Y (m_pRGB_buffer[location].R, m_pRGB_buffer[location].G, m_pRGB_buffer[location].B);
			location++;pos++;
		}
		location+=m_Ximage-8;
	}
    
    
}

void JpegEncoder::Precalculate_YCbCr_tables()
{
	WORD R,G,B;
	for (R=0;R<=255;R++) 
	{	
		m_YRtab[R]=(SDWORD)(19595.264)*R;
		m_CbRtab[R]=(SDWORD)(-11058.54464)*R;
		m_CrRtab[R]=(SDWORD)(32768)*R;
	}
	for (G=0;G<=255;G++) 
	{	
		m_YGtab[G]=(SDWORD)(38469.632)*G;
		m_CbGtab[G]=(SDWORD)(-21709.45536)*G;
		m_CrGtab[G]=(SDWORD)(-27439.26784)*G;
	}
	for (B=0;B<=255;B++)
	{
		m_YBtab[B]=(SDWORD)(7471.104)*B;
		m_CbBtab[B]=(SDWORD)(32768)*B;
		m_CrBtab[B]=(SDWORD)(-5328.73216)*B;
	}
}



void JpegEncoder::Prepare_quant_tables()
{
	double aanscalefactor[8] = {1.0, 1.387039845, 1.306562965, 1.175875602,
				   1.0, 0.785694958, 0.541196100, 0.275899379};
	 BYTE row, col;
	 BYTE i = 0;
	 for (row = 0; row < 8; row++)
	 {
	   for (col = 0; col < 8; col++)
		 {
		   m_fdtbl_Y[i] = (float) (1.0 / ((double) DQTinfo.Ytable[zigzag[i]] *
				  aanscalefactor[row] * aanscalefactor[col] * 8.0));
		   m_fdtbl_Cb[i] = (float) (1.0 / ((double) DQTinfo.Cbtable[zigzag[i]] *
				  aanscalefactor[row] * aanscalefactor[col] * 8.0));

		   i++;
		 }
	 }
}

void JpegEncoder::Process_DU(SBYTE *ComponentDU, float *fdtbl, SWORD *DC, bitstring *HTDC, bitstring *HTAC)
{
	bitstring EOB=HTAC[0x00];
	bitstring M16zeroes=HTAC[0xF0];
	BYTE i;
	BYTE startpos;
	BYTE end0pos;
	BYTE nrzeroes;
	BYTE nrmarker;
	SWORD Diff;

	Fdct_and_Quantization(ComponentDU,fdtbl,m_DU_DCT);
	//zigzag reorder
	for (i=0;i<=63;i++)
	{
		m_DU[zigzag[i]]=m_DU_DCT[i];
	}
	Diff=m_DU[0]-*DC;
	*DC=m_DU[0];
	//Encode DC
	if (Diff==0) Writebits(HTDC[0]); //Diff might be 0
	else 
	{
		Writebits(HTDC[m_pCategory[Diff]]);
		Writebits(m_pBitcode[Diff]);
	}
	//Encode ACs
	for (end0pos=63;(end0pos>0)&&(m_DU[end0pos]==0);end0pos--) ;
	if (end0pos==0) 
	{
		Writebits(EOB);
		return;
	}

	i=1;
	while (i<=end0pos)
	{
		startpos=i;
		for (; (m_DU[i]==0)&&(i<=end0pos);i++) ;
		nrzeroes=i-startpos;
		if (nrzeroes>=16) 
		{
		  for (nrmarker=1;nrmarker<=nrzeroes/16;nrmarker++) Writebits(M16zeroes);
		  nrzeroes=nrzeroes%16;
		}
		Writebits(HTAC[nrzeroes*16+m_pCategory[m_DU[i]]]);
		Writebits(m_pBitcode[m_DU[i]]);
		i++;
	}
	if (end0pos!=63) Writebits(EOB);
}

void JpegEncoder::Set_DHTinfo()
{
	BYTE i;
	DHTinfo.marker=0xC4FF;
	DHTinfo.length=0x1F00;
    DHTinfo.marker2=0xC4FF;
	DHTinfo.length2=0xB500;
    DHTinfo.marker3=0xC4FF;
	DHTinfo.length3=0x1F00;
    DHTinfo.marker4=0xC4FF;
	DHTinfo.length4=0xB500;
	DHTinfo.HTYDCinfo=0;
	for (i=0;i<16;i++)  DHTinfo.YDC_nrcodes[i]=std_dc_luminance_nrcodes[i+1];
	for (i=0;i<=11;i++)  DHTinfo.YDC_values[i]=std_dc_luminance_values[i];
	DHTinfo.HTYACinfo=0x10;
	for (i=0;i<16;i++)  DHTinfo.YAC_nrcodes[i]=std_ac_luminance_nrcodes[i+1];
	for (i=0;i<=161;i++) DHTinfo.YAC_values[i]=std_ac_luminance_values[i];
	DHTinfo.HTCbDCinfo=1;
	for (i=0;i<16;i++)  DHTinfo.CbDC_nrcodes[i]=std_dc_chrominance_nrcodes[i+1];
	for (i=0;i<=11;i++)  DHTinfo.CbDC_values[i]=std_dc_chrominance_values[i];
	DHTinfo.HTCbACinfo=0x11;
	for (i=0;i<16;i++)  DHTinfo.CbAC_nrcodes[i]=std_ac_chrominance_nrcodes[i+1];
	for (i=0;i<=161;i++) DHTinfo.CbAC_values[i]=std_ac_chrominance_values[i];
}

void JpegEncoder::Set_DQTinfo(BYTE scalefactor)
{

	DQTinfo.marker=0xDBFF;
	DQTinfo.length=0x4300;
    DQTinfo.marker2=0xDBFF;
	DQTinfo.length2=0x4300;
	DQTinfo.QTYinfo=0;
	DQTinfo.QTCbinfo=1;
	Set_quant_table(std_luminance_qt,scalefactor,DQTinfo.Ytable);
	Set_quant_table(std_chrominance_qt,scalefactor,DQTinfo.Cbtable);
}

void JpegEncoder::Set_numbers_category_and_bitcode()
{
	SDWORD nr;
	SDWORD nrlower,nrupper;
	BYTE cat;


	m_pCategory_alloc= new BYTE [(65535*sizeof(BYTE))];
	m_pCategory=m_pCategory_alloc+32767; //allow negative subscripts

	m_pBitcode_alloc=new bitstring [65535*sizeof(bitstring)];
	m_pBitcode=m_pBitcode_alloc+32767;
	nrlower=1;nrupper=2;
	for (cat=1;cat<=15;cat++)
	{
				 //Positive numbers
		for (nr=nrlower;nr<nrupper;nr++)
		{ 
			m_pCategory[nr]=cat;
			m_pBitcode[nr].length=cat;
			m_pBitcode[nr].value=(WORD)nr;
		}
		//Negative numbers
		for (nr=-(nrupper-1);nr<=-nrlower;nr++)
		{ 
			m_pCategory[nr]=cat;
			m_pBitcode[nr].length=cat;
			m_pBitcode[nr].value=(WORD)(nrupper-1+nr);
		}
		nrlower<<=1;
		nrupper<<=1;
	}
}

void JpegEncoder::Set_quant_table(BYTE *basic_table, BYTE scale_factor, BYTE *newtable)
{
	BYTE i;
	long temp;
	if(scale_factor <= 0)	scale_factor = 1;
	else if(scale_factor >= 100)	scale_factor = 100;

	for (i = 0; i < 64; i++)
	{
		temp = ((long) basic_table[i] *(100-scale_factor) ) / 50L;
		/* limit the values to the valid range */
		if (temp <= 0L) temp = 1L;
		if (temp > 255L) temp = 255L; /* limit to baseline range if requested */
		newtable[zigzag[i]] = (BYTE) temp;
	}
}

void JpegEncoder::Write_comment(char *comment)
{
	WORD length;
	writeword(0xFFFE); //The COM marker
	length=strlen((const char *)comment);
	writeword(length+2);
	memcpy(m_pFile_Temp,comment,length+2);
	m_pFile_Temp+=length+2;
	m_Byte_Count+=length+2;
}

void JpegEncoder::Writebits(bitstring bs)
{
	WORD value;
	BYTE Zero=0;
	SBYTE posval;//bit position in the bitstring we read, should be<=15 and >=0
	value=bs.value;
	posval=bs.length;
	int k=posval+bytepos;
	if(k<16)
	{
		bytenew|=(value<<(16-k));
		bytepos+=posval;
		if((bytenew>>8)==0xFF)
		{
			
			*m_pFile_Temp=0xFF;
			m_Byte_Count++;
			m_pFile_Temp++;
			*m_pFile_Temp=0x00;
			m_Byte_Count++;
			m_pFile_Temp++;
			bytenew<<=8;
			bytepos-=8;
		}
		
	}
	else if(k==16)
	{
		bytenew|=value;
		BYTE ByteHi=(bytenew>>8);
		BYTE ByteLo=(bytenew&0x00FF);
		if ((ByteHi)==0xFF) 
		{
			*m_pFile_Temp=0xFF;
			m_Byte_Count++;
			m_pFile_Temp++;
			*m_pFile_Temp=0x00;
			m_Byte_Count++;
			m_pFile_Temp++;
			if ((ByteLo)==0xFF) 
			{
				*m_pFile_Temp=0xFF;
				m_Byte_Count++;
				m_pFile_Temp++;
				*m_pFile_Temp=0x00;
				m_Byte_Count++;
				m_pFile_Temp++;
			
			}
			else
			{
				*m_pFile_Temp=(ByteLo);
				m_Byte_Count++;
				m_pFile_Temp++;
				
			}
		}
		else
		{
			*m_pFile_Temp=ByteHi;
			m_Byte_Count++;
			m_pFile_Temp++;
			if ((ByteLo)==0xFF) 
			{
				*m_pFile_Temp=0xFF;
				m_Byte_Count++;
				m_pFile_Temp++;
				*m_pFile_Temp=0x00;
				m_Byte_Count++;
				m_pFile_Temp++;
		
			}
			else
			{
				*m_pFile_Temp=(ByteLo);
				m_Byte_Count++;
				m_pFile_Temp++;
			
			}
		}
		bytepos=0;bytenew=0;
	}
	else
	{
		int k2=posval-(16-bytepos);
		bytenew|=(value>>(k2));
		BYTE ByteHi=(bytenew>>8);
		BYTE ByteLo=(bytenew&0x00FF);
		if ((ByteHi)==0xFF) 
		{
			*m_pFile_Temp=0xFF;
			m_Byte_Count++;
			m_pFile_Temp++;
			*m_pFile_Temp=0x00;
			m_Byte_Count++;
			m_pFile_Temp++;
			if ((ByteLo)==0xFF) 
			{
				*m_pFile_Temp=0xFF;
				m_Byte_Count++;
				m_pFile_Temp++;
				*m_pFile_Temp=0x00;
				m_Byte_Count++;
				m_pFile_Temp++;
				
			}
			else
			{
				*m_pFile_Temp=(ByteLo);
				m_Byte_Count++;
				m_pFile_Temp++;
				
			}
		}
		else
		{
			*m_pFile_Temp=ByteHi;
			m_Byte_Count++;
			m_pFile_Temp++;
			if ((ByteLo)==0xFF) 
			{
				*m_pFile_Temp=0xFF;
				m_Byte_Count++;
				m_pFile_Temp++;
				*m_pFile_Temp=0x00;
				m_Byte_Count++;
				m_pFile_Temp++;
				
			}
			else
			{
				*m_pFile_Temp=(ByteLo);
				m_Byte_Count++;
				m_pFile_Temp++;
			
			}
		}
		bytepos=0;bytenew=0;
		
		bytenew|=(value<<(16-k2));
		bytepos+=k2;
		if((bytenew>>8)==0x00FF)
		{
			
			*m_pFile_Temp=0xFF;
			m_Byte_Count++;
			m_pFile_Temp++;
			*m_pFile_Temp=0x00;
			m_Byte_Count++;
			m_pFile_Temp++;
			bytenew<<=8;
			bytepos-=8;
		}
	}

}


BYTE * JpegEncoder::GetJpegFileStream(DWORD *Jpg_FileSize)
{
    if(m_pFile_Temp_Org != NULL){       
        *Jpg_FileSize = m_Byte_Count;
        return m_pFile_Temp_Org;
    }
    else{
        return NULL;
    }

}


bool JpegEncoder::Compressor(BYTE *Bitmap, WORD nWidth_original, WORD nHeight_original, BYTE Quality)
{
	m_Byte_Count=0;
	bitstring fillbits; //filling bitstring for the bit alignment of the EOI marker
	Prepare_RGB(Bitmap, &nWidth_original, &nHeight_original);

	m_TempSize=(nWidth_original)*(nHeight_original)*3;

    if(m_pFile_Temp_Org != NULL)
        delete [] m_pFile_Temp_Org;

	if(!(m_pFile_Temp_Org=new BYTE[m_TempSize])) 
        return false ;
	m_pFile_Temp = m_pFile_Temp_Org;
	
	Init_all(Quality);
	SOF0info.width=(((nWidth_original)>>8)|((nWidth_original)<<8));
	SOF0info.height=(((nHeight_original)>>8)|((nHeight_original)<<8));
	writeword(0xFFD8); //SOI
	Write_APP0info();
	Write_DHTinfo();
    Write_DQTinfo();
	Write_SOF0info();	
	Write_SOSinfo();

	bytenew=0;bytepos=0;

	Encoder2x1();

	//Do the bit alignment of the EOI marker
	if (bytepos<16) 
	{
		fillbits.length=16-bytepos;
		fillbits.value=(1<<(fillbits.length))-1;
		Writebits(fillbits);
	}
	writeword(0xFFD9); //EOI
    m_pFile_Temp_Org[0x08] = Quality;
    m_pFile_Temp_Org[0x16] = (unsigned char)(m_Byte_Count&0x000000FF);
    m_pFile_Temp_Org[0x17] = (unsigned char)((m_Byte_Count>>8)&0x000000FF);
	
	delete [] m_pCategory_alloc;
	delete [] m_pBitcode_alloc;

	
	return true;
}




