// StartDlgDlg.cpp : implementation file
//

#include "stdafx.h"
#include "stdio.h"
#include "StartDlg.h"
#include "StartDlgDlg.h"
#include <stdlib.h>
//#include <MtVerify.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
DWORD WINAPI ThreadFunc(LPVOID);
unsigned char *pImage;
unsigned short gWidth,gHeight;
int Needtime;
CRITICAL_SECTION critical_sec,critical_sec1,critical_sec2,critical_sec3,critical_sec4,critical_sec5,critical_sec6
,critical_sec7,critical_sec8,critical_sec9,critical_sec10,critical_sec11,critical_sec12,critical_sec13,
critical_sec14,critical_sec15;
//JpegEncoder Jpeg,Jpeg2;
static int ObjNum=0;
static int Thrswitch;
static int key=1;
HANDLE phThrd_JpgSave;
HANDLE hFile;
OVERLAPPED overlap;
DWORD numwrite;
#define ThreadNum 4
#define LoopNum 300
//JpegEncoder Jpeg,Jpeg1,Jpeg2,Jpeg3,Jpeg4,Jpeg5,Jpeg6,Jpeg7,Jpeg8,Jpeg9,Jpeg10,Jpeg11,Jpeg12,Jpeg13,Jpeg14,Jpeg15;
//DataInfo *ImageData;
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT


}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStartDlgDlg dialog

CStartDlgDlg::CStartDlgDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CStartDlgDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CStartDlgDlg)

	m_FileName = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CStartDlgDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStartDlgDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CStartDlgDlg, CDialog)
	//{{AFX_MSG_MAP(CStartDlgDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_OpenFile_BUTTON, OnOpenFileBUTTON)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStartDlgDlg message handlers

BOOL CStartDlgDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	
	CEdit *pco = (CEdit *)GetDlgItem(IDC_EDIT_FileSize);
	pco->SetWindowText(_T("64"));
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CStartDlgDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CStartDlgDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CStartDlgDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CStartDlgDlg::OnOpenFileBUTTON() 
{
	// TODO: Add your control notification handler code here
    int FileNum;
	CString pathName; 
	CString  NameTemp;
    JpegEncoder Jpeg;
	//Get filename from the Edit Box
	CStringA csTmp("BMP Files (*.bmp)|*.bmp|All Files (*.*)|*.*||");
	CFileDialog dlg(TRUE, NULL, NULL, OFN_ALLOWMULTISELECT, csTmp, this);
	dlg.GetOFN().lpstrFile=NameTemp.GetBuffer(300000);
	dlg.GetOFN().nMaxFile = 3000;
	if(dlg.DoModal()==IDOK)
	{			
        POSITION mPos=dlg.GetStartPosition(); 
		FileNum=0;
        while(mPos!=NULL) 
        { 
			pathName=dlg.GetNextPathName(mPos); 
			FileNum++;
		}
		mPos=dlg.GetStartPosition(); 
		FileNum=0;

        while(mPos!=NULL) 
        {
            FileNum++;
            unsigned char TMPBUF[256];
	        unsigned char  nr_fillingbytes;
	        unsigned char *pPos;
	        int nrline;
	        CFile pFileSave;
	        CFileException e;
            m_FileName=dlg.GetNextPathName(mPos);	
            if( !(pFileOpen).Open(m_FileName, CFile::modeRead|CFile::typeBinary, &e ) )
	        {
                AfxMessageBox("Can't open",MB_OK,0);
	        }
	        else
            {
                //Decode BMP File
                pFileOpen.Read(TMPBUF,54);			    
		        nWidth=(WORD)TMPBUF[19]*256+TMPBUF[18];
		        nHeight=(WORD)TMPBUF[23]*256+TMPBUF[22];	
		        if ((nWidth*3)%4!=0) nr_fillingbytes=4-((nWidth*3)%4);
	            else nr_fillingbytes=0;
		        pbuf=new unsigned char[nWidth*nHeight*3];
		        pFileOpen.Seek(54,CFile::begin);
		        pPos=pbuf;
		        for (nrline=0;nrline<nHeight;nrline++,pPos+=nWidth*3)
		        {        		   
			        pFileOpen.Read(pPos,nWidth*3);
			        pFileOpen.Read(TMPBUF,nr_fillingbytes);
		        }
		        pBitbuffer=new unsigned char[nWidth*nHeight*3];
		        unsigned char *pCpy,*pOrg;
		        int i;
		        pOrg=pbuf;
		        pCpy=pBitbuffer;
		        pOrg+=nWidth*3*(nHeight-1);
		        int Rownum=(nHeight/8);

		        for(i=0;i<nHeight;i++)
		        {
		            memcpy(pCpy,pOrg,nWidth*3);
		            pCpy+=nWidth*3;
		            pOrg-=nWidth*3;
		        }
		        pImage=pBitbuffer;
		        gWidth=nWidth;
		        gHeight=nHeight;
		        delete [] pbuf;
                pFileOpen.Close();

                CString strOptFile = m_FileName;
                strOptFile.Replace(_T(".bmp"), _T(".jpg"));
                  
                  
                 //Get Max Jpg File size
                 CEdit *pco = (CEdit *)GetDlgItem(IDC_EDIT_FileSize);
	             CString lpszStringBuf;
                 pco->GetWindowText(lpszStringBuf);
	             int target_file_size =  _ttoi(lpszStringBuf);
	             target_file_size *= 1024;
	                                
                  
                //Encode T582 Jpg
                unsigned char * p_Jpg_FStream = NULL;
                unsigned long Jpg_FSize = 0x1000000;
                unsigned char Quality = 95;
                bool rc;
                
                //Try to Encode Jpeg <= 64K Byte
                while((Jpg_FSize>(unsigned long)(target_file_size))&&(Quality>0)){
	                rc = Jpeg.Compressor(pBitbuffer, nWidth, nHeight, Quality);                
                    if(rc){
                        p_Jpg_FStream = Jpeg.GetJpegFileStream(&Jpg_FSize);
                        Quality -= 5;
                    }
                }
                if(rc){
                    if(Jpg_FSize && (p_Jpg_FStream!=NULL)){
                        CFile Jpeg_File;
                        Jpeg_File.Open(strOptFile.GetString(),CFile::modeCreate | CFile::modeWrite|CFile::typeBinary, &e);
                        Jpeg_File.Write(p_Jpg_FStream, Jpg_FSize);
                        Jpeg_File.Close();
                    }
                }

            }
        }


    }
	//stepdct.takePix(&pFileOpen);
    AfxMessageBox("Encode Done.",MB_OK,0);
}



void CStartDlgDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}
void CStartDlgDlg::OnOK() 
{
	// TODO: Add extra cleanup here
	
}
void CStartDlgDlg::OnChangeFileNameEDIT() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	
}

